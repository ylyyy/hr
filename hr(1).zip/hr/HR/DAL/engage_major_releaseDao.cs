﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IDAL;

namespace DAL
{
    class engage_major_releaseDao:BaseDao,Iengage_major_releaseDao
    {
    }
}
