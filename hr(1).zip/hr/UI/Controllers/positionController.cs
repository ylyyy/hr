﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UI.Controllers
{
    public class positionController : Controller
    {
        // GET: position
        public ActionResult position_register()
        {
            return View();
        }
    }
}