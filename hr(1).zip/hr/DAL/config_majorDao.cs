﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IDAL;

namespace DAL
{
    class config_majorDao:BaseDao,Iconfig_majorDao
    {

    }
}
