﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IDAL;

namespace DAL
{
    class engage_resumeDao:BaseDao,Iengage_resumeDao
    {
    }
}
