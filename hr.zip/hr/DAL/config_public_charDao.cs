﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IDAL;

namespace DAL
{
    class config_public_charDao:BaseDao,Iconfig_public_charDao
    {

    }
}
